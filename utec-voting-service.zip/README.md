# utec-voting-service
Servicio demo para votaciones
